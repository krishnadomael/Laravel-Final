
<?php $__env->startSection('title'); ?>
To do list

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container p-3">
  <div class="card"style="width:100%; height:700px;">
     <div class="card-header">Modified CRUD Demo</div>
     <b><h5 class="shadow-text mt-3" style="margin-left:40px;">Events Management System</b></h5>
     <a href="<?php echo e(route('tasks.create')); ?>">
    <span class="glyphicon glyphicon-plus-sign text-dark mt-3 fa-lg" style="margin-left:40px; font-size: 15px;"></span></a><br>
  <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-6 col-md-4 mb-3">
    <div class="card-rounded-3" style="width: 17rem; margin-left:40px;">
      <div class="card-body bg-info">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
         
          <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo e(method_field('delete')); ?>

            <button class="glyphicon glyphicon-remove-sign text-danger" style="border: none; background-color: inherit; text-decoration: none;" onclick="return confirm(' Are you sure you want to delete?')"  style="margin-left:160px;">
          </button>
          </form>
        </div>
         <center><b><h5 class="mb-5"><?php echo e($task->event_name); ?></b></h5></center>
        <div class="text-center">
          <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="glyphicon glyphicon-eye-open text-primary fa-lg"style="margin-right:40px; margin-left:20px; font-size: 17px;"></a>
          <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="glyphicon glyphicon-edit text-secondary fa-lg"style="font-size: 17px;"></a>
         <!--  <span class="glyphicon glyphicon-edit"></span> -->
        </div>
        </div>
      </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>    




<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\app5\resources\views/pages/home.blade.php ENDPATH**/ ?>