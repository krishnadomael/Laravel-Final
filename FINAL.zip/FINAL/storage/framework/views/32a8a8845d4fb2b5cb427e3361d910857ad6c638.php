
<?php $__env->startSection('title'); ?>
To do list

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header bg-light">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <b><a class="nav-link active text-primary" aria-current="true" href="#">Home</b></a>
      </li>
      <li class="nav-item">
        <b><a class="nav-link bg-secondary text-dark" href="<?php echo e(route('tasks.create')); ?>">Add Task</b></a>
      </li>
    </ul>
  </div>
  <div class="card-body">
    <div class="row">
            
        <table class="table">
            <thead>
                <tr>
                    <td with="80px"><b>ID</b></td>
                    <td><b>Task</b></td>
                    <td><b>Done</b></td>
                    <td><b>Show</b></td>
                    <td><b>Edit</b></td>
                    <td><b>Delete</b></td>
                </tr>    
               
            </thead>
            <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($task->id); ?></td>
                    <td><h5><?php echo e($task->task_column); ?></h5></td>
                    <!-- Done -->
                    <td>
                    <?php if($task->done === 0): ?>
                    <a href="<?php echo e(route('done', $task->id)); ?> "class="btn btn-danger">False</a>
                    <?php elseif($task->done=== 1): ?>
                    <a href="<?php echo e(route('done', $task->id)); ?> "class="btn btn-secondary">True</a>
                    <?php endif; ?>        
                    </td>
                    <td>
                    <!-- Show -->
                        <span>
                            <button><a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="glyphicon glyphicon-eye-open">Show</a>
                    </span></td></button>
                  
                    <!-- Edit -->
                    <td>
                    <span>
                        <button><a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="glyphicon glyphicon-check"></span>Edit</a>
                    </button></span></td>
                    <!-- Delete -->
                <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <td>
                    <input type="hidden" name="_method" value="DELETE">
                    <button>
                        <span class="glyphicon glyphicon-trash" type="submit" name="submit" onclick="return confirm(' Are you sure you want to delete?')">Delete
                        </span></button></td>   
                    
                </form></tr>    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
</div>
<?php $__env->stopSection(); ?>                


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\app6\resources\views/pages/home.blade.php ENDPATH**/ ?>