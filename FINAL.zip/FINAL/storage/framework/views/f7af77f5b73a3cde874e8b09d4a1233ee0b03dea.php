
<?php $__env->startSection('title'); ?>
    Specific Task

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container p-5">
  <div class="card-header">Modified CRUD Demo</div>
    <div class="card"style="width:100%; height:320px; background-color:#c0c0c0;">
      <div class="card-body mt-5 bg-light" 
      style="margin-left:40px; width:45%; margin-left:180px;">

      <b><h4 class="shadow-text" style="margin-left:40px;">Event Details</b></h4><br><br>
        <div class="card-body pt-1"style="margin-left:65px;">
          <td>
          <b><h5>Event: </b><?php echo e($task->event_name); ?></h5><br>
          <b><h5>Schedule: </b><?php echo e($task->date); ?></h5><br>
          <b><h5>Venue: </b><?php echo e($task->venue); ?></h5><br>
          <b><h5>In Charge: </b><?php echo e($task->incharge); ?></h5><br>
        </td>
        </div>

  <a class="btn btn-dark btn-rounded text-light" href="<?php echo e(route('tasks.index')); ?>"style="margin-left:125px;">Back</a>
    </div>
      </div>
    </div>
</div>

      
<?php $__env->stopSection(); ?>                
                    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\app5\resources\views/pages/task.blade.php ENDPATH**/ ?>