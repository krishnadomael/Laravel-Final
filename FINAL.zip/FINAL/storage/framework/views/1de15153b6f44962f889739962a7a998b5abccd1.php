
<?php $__env->startSection('title'); ?>
    Specific Task

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <b><a class="nav-link active text-primary" aria-current="true" href="#">Show Task</b></a>
      </li>
      <li class="nav-item">
        <b><a class="nav-link text-dark" href="<?php echo e(route('tasks.index')); ?>">Back</b></a>
      </li>
    </ul>
  </div>
  <div class="card-body"><br>
    <h3>The task is to <?php echo e($task->task_column); ?></h3>
    <h6>Is it done? <br><br>
        <?php if($task->done == 0): ?>
            <span class="text-danger">Not yet done</span>
        <?php else: ?>
            <span class="text-success">Yes. It is done;</span>
    <?php endif; ?></h6>

    </div>
      
<?php $__env->stopSection(); ?>                
                    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\app6\resources\views/pages/task.blade.php ENDPATH**/ ?>