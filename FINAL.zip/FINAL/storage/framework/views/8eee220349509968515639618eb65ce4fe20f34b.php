
<?php $__env->startSection('title'); ?>
Add Event

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container p-3">
  <div class="card"style="width:100%; height:500px;">

  <form action="<?php echo e(route('events.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>

<b><h5 class="shadow-text mt-4" style="margin-left:40px;">Add Event</b></h5>
          <div class="card-body mt-5" style="background-color: #c0c0c0; width:40%; height:230px; margin-left:240px; font-size: 15px;">
          <label for="inputname" class="col-sm-4 mt-4" style="margin-left:20px;">Event Name</label>
              <input type="name" class=" col-sm-6 form-label mt-4" name="event_input"required>

          <label for="inputname" class="col-sm-4" style="margin-left:20px;">Venue</label>
              <input type="name" class=" col-sm-6 form-label" name="venue_input"required>
      
          <label for="example-date-input" class="col-sm-4" style="margin-left:20px;">Date</label>
          <input class="col-sm-6 form-label" type="date" name="date_input"required>

          <label for="inputEmail3" class="col-sm-4" style="margin-left:20px;">In charge</label>
              <input type="in charge" class="col-sm-6 form-label" name="incharge_input"required>

              <button class=" mt-2 btn btn-primary mt-5" style="margin-right:30px; margin-left:130px;">Create
              </button>
              <a href="<?php echo e(route('events.index')); ?>" class="btn btn-secondary mt-5">Cancel</a>
              
      </div>
  </form>
  </div>
</div>

  <?php $__env->stopSection(); ?>                
                     
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\finalproject\resources\views/pages/add.blade.php ENDPATH**/ ?>