
<?php $__env->startSection('title'); ?>
Update 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container p-3">
  <div class="card"style="width:100%; height:500px;">

  <form action="<?php echo e(route('events.update', $event->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(@method_field('put')); ?>


<b><h5 class="shadow-text mt-4" style="margin-left:40px;">Update Event</b></h5>
          <div class="card-body mt-5" style="background-color: #c0c0c0; width:45%; height:250px; margin-left:230px;">

          <label for="inputname" class="col-sm-4 mt-4" style="margin-left:20px; font-size: 15px;" >Event Name</label>
              <input type="name" class=" col-sm-6 col-form-label mt-4" name="event_input" value="<?php echo e($event->event_name); ?>"><br><br><br>

          <label for="inputname" class="col-sm-4 mt-4"style="margin-left:20px; font-size: 15px;">Venue</label>
              <input type="name" class=" col-sm-6 col-form-label mt-4" name="venue_input"value="<?php echo e($event->venue); ?>">
              <br><br><br>
          
          <label for="example-date-input" class="col-sm-4 mt-4" style="margin-left:20px; font-size: 15px;">Date</label>
              <input class="col-sm-6 col-form-label mt-4" type="date" name="date_input" value="<?php echo e($event->date); ?>">
              <br><br><br>

          <label for="inputEmail3" class="col-sm-4 mt-4" style="margin-left:20px; font-size: 15px;">In charge</label>
              <input type="in charge" class="col-sm-6 col-form-label mt-4" name="incharge_input" value="<?php echo e($event->incharge); ?>"><br><br><br>  
          
            <button class=" mt-4 btn btn-primary" style="margin-right:30px; margin-left:130px;">Update</button>
            <a href="<?php echo e(route('events.index', $event->id)); ?>" class="mt-4 btn btn-secondary">Cancel</a>
       
              
      </div>
</form>
  </div>
        </div>
  
  <?php $__env->stopSection(); ?>                

 
  


  
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\finalproject\resources\views/pages/edit.blade.php ENDPATH**/ ?>