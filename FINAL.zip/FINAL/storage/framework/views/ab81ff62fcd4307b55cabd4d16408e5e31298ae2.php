
<?php $__env->startSection('title'); ?>
    Details

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container p-5">
  <div class="card-header">Modified CRUD Demo</div>
    <div class="card"style="width:100%; height:380px;">
      <div class="card-body mb-5 mt-5" style="margin-left:40px; width:40%; margin-left:240px; background-color: #C0C0C0;">

      <b><h4 class="shadow-text" style="margin-left:40px;">Event Details</b></h4><br><br>
        <div class="card-body"style="margin-left:65px;">
          <td>
          <b><h5 style="font-size: 15px;">Event: </b><?php echo e($event->event_name); ?></h5><br>
          <b><h5 style="font-size: 15px;"> Schedule: </b><?php echo e($event->date); ?></h5><br>
          <b><h5 style="font-size: 15px;">Venue: </b><?php echo e($event->venue); ?></h5><br>
          <b><h5 style="font-size: 15px;">In Charge: </b><?php echo e($event->incharge); ?></h5><br>
        </td>
        </div>

  <a class="btn btn-dark btn-rounded text-light mt-5" href="<?php echo e(route('events.index')); ?>"style="margin-left:150px;">Back</a>
    </div>
      </div>
    </div>
</div>

      
<?php $__env->stopSection(); ?>                
                    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\finalproject\resources\views/pages/event.blade.php ENDPATH**/ ?>