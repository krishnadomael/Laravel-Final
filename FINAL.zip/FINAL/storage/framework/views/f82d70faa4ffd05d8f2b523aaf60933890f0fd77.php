
<?php $__env->startSection('title'); ?>
Event

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container p-3">
    <div class="card-header">Modified CRUD Demo</div>
      <b><h5 class="mt-3" style="margin-left:40px;">Events Management System</b></h5>
      <a href="<?php echo e(route('events.create')); ?>">
      <span class="glyphicon glyphicon-plus-sign text-dark mt-5 fa-lg" style="margin-left:40px; font-size: 17px;"></span></a><br>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-6 col-md-4 mb-3 mt-5" style="width: 20%; margin-left:80px;">
        <div class="card-body" style="background-color: #6495ED; width: 140%; height: 150px;">
          <div class="d-grid gap-1 d-md-flex justify-content-md-end">
                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('delete')); ?>

                <button class="glyphicon glyphicon-remove-sign text-danger" style="border: none; background-color: inherit; text-decoration: none;" onclick="return confirm(' Are you sure you want to delete?')"  style="margin-left:160px;">
                </button>
                </form>
          </div>

          <center><b><h5 class="mb-5 mt-4" style="font-size: 17px;"><?php echo e($event->event_name); ?></b></h5></center>

            <div class="text-center pt-4">
            <a href="<?php echo e(route('events.show', $event->id)); ?>" class="btn btn bg-primary" 
              style="margin-right:40px; margin-left:5px; font-size: 10px;">View</a>
            <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn bg-secondary" style="font-size: 10px;">Edit</a>
            </div>
        </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</div>
<?php $__env->stopSection(); ?>    




<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\babs\FINAL\resources\views/pages/home.blade.php ENDPATH**/ ?>