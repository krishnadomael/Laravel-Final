
<?php $__env->startSection('title'); ?>
Edit task

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <b><a class="nav-link active text-primary" aria-current="true" href="#">Edit Task</b></a>
      </li>
      <li class="nav-item">
        <b><a class="nav-link text-dark" href="<?php echo e(route('tasks.index')); ?>">Back</b></a>
      </li>
    </ul>
  </div>
  <div class="card-body">
  <h4>Task</h4>
  <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
       <?php echo e(method_field('PUT')); ?>

            <input type="text" value="<?php echo e($task->task_column); ?>" class="form-control" name="task_input" required placeholder="Enter task here"> 
            <input type="submit" value="Update" class=" mt-2 btn btn-info text-white">
            
            
    </div>
</div>

  
  <?php $__env->stopSection(); ?>                

 
  


  
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\genel\Desktop\Laravel app\app6\resources\views/pages/edit.blade.php ENDPATH**/ ?>