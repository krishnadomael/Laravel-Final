<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;

class EventController extends Controller
{
   
    public function index()
    {
        $event = Event::all();
        return view("pages.home")->with("events", $event);
    }

    
    public function create()
    {
        return view("pages.add");
    
    }

 
    public function store(Request $request)
    {
        $event = new Event();
        
        $event->event_name = $request->event_input;
        $event->date = $request->date_input;
        $event->venue = $request->venue_input;
        $event->incharge = $request->incharge_input;

        $event->save();

        return redirect()->route('events.index');
    }

   
    public function show($id)
    {
        $event = Event::find($id);
        return view("pages.event")->with("event", $event);
    }

    
    public function edit($id)
    {
        $event = Event::find($id);
        return view("pages.edit")->with("event", $event);
    }

    
    public function update(Request $request, $id)
    {
        $event = Event::find($id);
        $event->event_name = $request->event_input;
        $event->date = $request->date_input;
        $event->venue = $request->venue_input;
        $event->incharge = $request->incharge_input;
        $event->save();
        return redirect()->route('events.index');
    }


    public function destroy($id)
    {
        $event = Event::find($id);
        $event->delete();
        return redirect()->route('events.index');
    }
}
